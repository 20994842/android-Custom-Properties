package com.example.lenovo.custom_textview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Button button_1;
    private Button button_2;
    private Button button_3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button_1 = (Button) findViewById(R.id.button_1);
        button_2 = (Button) findViewById(R.id.button_2);
        button_3 = (Button) findViewById(R.id.button_3);


        button_1.setOnClickListener(this);
        button_2.setOnClickListener(this);
        button_3.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.button_1:
                Intent intent=new Intent(this,CustomAtrrs1Activity.class);
                startActivity(intent);
                break;
            case R.id.button_2:
                Intent intent2=new Intent(this,CustomAtrrs2Activity.class);
                startActivity(intent2);
                break;
            case R.id.button_3:
                Intent intent3=new Intent(this,CustomAtrrs3Activity.class);
                startActivity(intent3);
                break;
            default:
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

//    主要有三种方法可以实现自定义属性。
//
//
//    第一种方法，直接设置属性值，通过attrs.getAttributeResourceValue拿到这个属性值。
//
//            (1)在xml文件中设置属性值
//
//    [html] view plaincopy
//
//    <com.example.activity.IconTextView
//    android:layout_width="fill_parent"
//    android:layout_height="wrap_content"
//    android:text="@string/smile1"
//    iconSrc="@drawable/smile"/>
//
//
//            (2)在构造函数中拿到这个值
//
//    [java] view plaincopy
//
//    public IconTextView(Context context, AttributeSet attrs) {
//        super(context, attrs);
//        resourceID = attrs.getAttributeResourceValue(null, "iconSrc", 0);
//        if(resourceID > 0) {
//            bitmap = BitmapFactory.decodeResource(getResources(), resourceID);
//        }
//    }
//
//
//    第二种方法，使用自己的命名空间
//
//            (1)注意在xml文件中，需要声明一个命名空间，形式为http:// + 这个VIEW的包名
//
//            [html] view plaincopy
//
//    <LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
//    xmlns:mobile="http://com.example.activity"
//    android:layout_width="fill_parent"
//    android:layout_height="fill_parent"
//    android:orientation="vertical" >
//
//    <com.example.activity.IconTextView
//    android:layout_width="fill_parent"
//    android:layout_height="wrap_content"
//    android:text="@string/smile1"
//    mobile:iconSrc="@drawable/smile"/>
//
//    </LinearLayout>
//
//
//            (2)通过attrs.getAttributeResourceValue，其中第一个参数为命名空间。
//
//            [java] view plaincopy
//
//    //命名空间
//    private final String namespace = "http://com.example.activity"
//
//            [java] view plaincopy
//
//    public IconTextView(Context context, AttributeSet attrs) {
//        super(context, attrs);
//        resourceID = attrs.getAttributeResourceValue(namespace, "iconSrc", 0);
//        //      TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.IconTextView);
//        //      resourceID = array.getResourceId(R.styleable.IconTextView_iconSrc, 0);
//        if(resourceID > 0) {
//            bitmap = BitmapFactory.decodeResource(getResources(), resourceID);
//        }
//    }
//
//
//    第三种方法，通过自定义attrs.xml来实现
//
//            (1)自定义一个attrs.xml文件
//
//    [html] view plaincopy
//
//    <?xml version="1.0" encoding="utf-8"?>
//    <resources>
//    <declare-styleable name="IconTextView">
//    <attr name="iconSrc" format="reference"/>
//    </declare-styleable>
//    </resources>
//
//
//            (2)在xml文件中使用这一属性，注意此时命名空间的书写规范。
//
//            [html] view plaincopy
//
//    <?xml version="1.0" encoding="utf-8"?>
//    <LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
//    xmlns:mobile="http://schemas.android.com/apk/res/com.example.activity"
//    android:layout_width="fill_parent"
//    android:layout_height="fill_parent"
//    android:orientation="vertical" >
//
//    <com.example.activity.IconTextView
//    android:layout_width="fill_parent"
//    android:layout_height="wrap_content"
//    android:text="@string/smile1"
//    mobile:iconSrc="@drawable/smile"/>
//
//    <com.example.activity.IconTextView
//    android:layout_width="fill_parent"
//    android:layout_height="wrap_content"
//    android:text="@string/smile2"
//    android:textSize="24dp"
//    mobile:iconSrc="@drawable/smile"/>
//
//    <com.example.activity.IconTextView
//    android:layout_width="fill_parent"
//    android:layout_height="wrap_content"
//    android:text="@string/smile3"
//    android:textSize="36dp"
//    mobile:iconSrc="@drawable/smile"/>
//
//
//    </LinearLayout>
//
//            (3)在代码中使用context.obtainStyledAttributes获得属性值
//
//    [java] view plaincopy
//
//    package com.example.activity;
//
//    import android.content.Context;
//    import android.content.res.TypedArray;
//    import android.graphics.Bitmap;
//    import android.graphics.BitmapFactory;
//    import android.graphics.Canvas;
//    import android.graphics.Rect;
//    import android.util.AttributeSet;
//    import android.widget.TextView;
//
//    public class IconTextView extends TextView {
//        //命名空间
//        private final String namespace = "http://com.example.activity";
//        //资源ID
//        private int resourceID = 0;
//        private Bitmap bitmap;
//
//        public IconTextView(Context context, AttributeSet attrs) {
//            super(context, attrs);
//            TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.IconTextView);
//            resourceID = array.getResourceId(R.styleable.IconTextView_iconSrc, 0);
//            if(resourceID > 0) {
//                bitmap = BitmapFactory.decodeResource(getResources(), resourceID);
//            }
//        }
//
//        @Override
//        public void onDraw(Canvas canvas) {
//            if (bitmap != null) {
//                Rect src = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
//
//                Rect target = new Rect();
//                int textHeight = (int)getTextSize();
//                target.left = 0;
//                target.top =(int)(getMeasuredHeight() - getTextSize()) / 2 + 1;
//                target.bottom = target.top + textHeight;
//                target.right = (int)(textHeight * (bitmap.getWidth() / (float)bitmap.getHeight()));
//
//                canvas.drawBitmap(bitmap, src, target, getPaint());
//
//                canvas.translate(target.right + 2, 0);
//            }
//
//            super.onDraw(canvas);
//        }
//
//    }
//

}
