package com.example.lenovo.custom_textview;

        import android.content.Context;
        import android.content.res.TypedArray;
        import android.graphics.Bitmap;
        import android.graphics.BitmapFactory;
        import android.graphics.Canvas;
        import android.graphics.Rect;
        import android.graphics.drawable.Drawable;
        import android.util.AttributeSet;
        import android.widget.TextView;

/**
 * Created by lenovo on 2016/2/18.
 */
public class ImageTextView3 extends TextView {
    public ImageTextView3(Context context) {
        super(context);
    }
    public ImageTextView3(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.ImageTextView);
        double iamgeDimension = typedArray.getDimension(R.styleable.ImageTextView_iamgeDimension, 0);
        int imageReference = typedArray.getResourceId(R.styleable.ImageTextView_imageReference, 0);
        bitmap = BitmapFactory.decodeResource(getResources(), imageReference);
        Drawable drawable = typedArray.getDrawable(R.styleable.ImageTextView_imageReference);
        double iamgeColor = typedArray.getColor(R.styleable.ImageTextView_iamgeColor, 0);
        String iamgeString = typedArray.getString(R.styleable.ImageTextView_iamgeString);
        double iamgeInteger = typedArray.getInteger(R.styleable.ImageTextView_iamgeInteger, 0);
        double iamgeFloat = typedArray.getFloat(R.styleable.ImageTextView_iamgeFloat, 0);
        boolean iamgeBoolean = typedArray.getBoolean(R.styleable.ImageTextView_iamgeBoolean, false);

//        ImageTextView:iamgeFraction="200%"
//        ImageTextView:iamgeFraction="200%p"
//         double iamgeFraction = typedArray.getFraction(R.styleable.ImageTextView_iamgeFraction, 4, 5, 1);
//        1）如果mageTextView_iamgeFraction 是200%，那么result就是：200%*4 ～ 8
//        2）如果mageTextView_iamgeFraction 是200%p，那么result就是：200%*5 ~ 10
        double iamgeFraction = typedArray.getFraction(R.styleable.ImageTextView_iamgeFraction, 4, 5, 1);
        double iamgeEnum1 = typedArray.getInteger(R.styleable.ImageTextView_iamgeEnum1, 0);
        double iamgeFlag = typedArray.getInteger(R.styleable.ImageTextView_iamgeFlag, 0);
        typedArray.recycle(); //调用结束后务必调用recycle()方法，否则这次的设定会对下次的使用造成影响
        StringBuffer str = new StringBuffer();
        str.append("iamgeDimension=  " + iamgeDimension + "\n");
        str.append("imageReference=  " + imageReference + "\n");
        str.append("iamgeColor=  " + iamgeColor + "\n");
        str.append("iamgeBoolean=  " + iamgeBoolean + "\n");
        str.append("iamgeString=  " + iamgeString + "\n");
        str.append("iamgeInteger=  " + iamgeInteger + "\n");
        str.append("iamgeFloat=  " + iamgeFloat + "\n");
        str.append("iamgeFraction=  " + iamgeFraction + "\n");
        str.append("iamgeEnum1=  " + iamgeEnum1 + "\n");
        str.append("iamgeFlag=  " + iamgeFlag + "\n");
        setText(str.toString());

    }

    public ImageTextView3(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private Bitmap bitmap;

    @Override
    public void onDraw(Canvas canvas) {
        if (bitmap != null) {
            Rect src = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

            Rect target = new Rect();
            int textHeight = (int) getTextSize();
            target.left = 0;
            target.top = (int) (getMeasuredHeight() - getTextSize()) / 2 + 1;
            target.bottom = target.top + textHeight;
            target.right = (int) (textHeight * (bitmap.getWidth() / (float) bitmap.getHeight()));
            canvas.drawBitmap(bitmap, src, target, getPaint());
            canvas.translate(target.right + 2, 0);
        }

        super.onDraw(canvas);
    }
}
