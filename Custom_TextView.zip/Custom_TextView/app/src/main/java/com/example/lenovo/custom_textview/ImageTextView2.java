package com.example.lenovo.custom_textview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Created by lenovo on 2016/2/18.
 */
public class ImageTextView2 extends TextView {
    public ImageTextView2(Context context) {
        super(context);
    }
    //命名空间
    private final String namespace = "http://com.example.activity";
    String tag = "ldq";
    public ImageTextView2(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public ImageTextView2(Context context, AttributeSet attrs) {
        super(context, attrs);

        //可以获取所有属性值的字符串表示，int,flat,boolea,reference,string 类型能获取准确值
        String iamgeDimension = attrs.getAttributeValue(namespace, "iamgeDimension");
        int imageReference = attrs.getAttributeResourceValue(namespace, "imageReference", 0);
        if (imageReference > 0) {
            bitmap = BitmapFactory.decodeResource(getResources(), imageReference);
        }
        String iamgeColor = attrs.getAttributeValue(namespace, "iamgeColor");
        String iamgeString = attrs.getAttributeValue(namespace, "iamgeString");
        int iamgeInteger = attrs.getAttributeIntValue(namespace, "iamgeInteger", 0);
        float iamgeFloat = attrs.getAttributeFloatValue(namespace, "iamgeFloat", 0);
        boolean iamgeBoolean = attrs.getAttributeBooleanValue(namespace, "iamgeBoolean", false);
        String iamgeFraction = attrs.getAttributeValue(namespace, "iamgeFraction");
        String iamgeEnum1 = attrs.getAttributeValue(namespace, "iamgeEnum1");
        String iamgeFlag = attrs.getAttributeValue(namespace, "iamgeFlag");

        StringBuffer str = new StringBuffer();
        str.append("iamgeDimension=  " + iamgeDimension + "\n");
        str.append("imageReference=  " + imageReference + "\n");
        str.append("iamgeColor=  " + iamgeColor + "\n");
        str.append("iamgeBoolean=  " + iamgeBoolean + "\n");
        str.append("iamgeString=  " + iamgeString + "\n");
        str.append("iamgeInteger=  " + iamgeInteger + "\n");
        str.append("iamgeFloat=  " + iamgeFloat + "\n");
        str.append("iamgeFraction=  " + iamgeFraction + "\n");
        str.append("iamgeEnum1=  " + iamgeEnum1 + "\n");
        str.append("iamgeFlag=  " + iamgeFlag + "\n");
       setText(str.toString());
    }


    private Bitmap bitmap;

    @Override
    public void onDraw(Canvas canvas) {
        if (bitmap != null) {
            Rect src = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

            Rect target = new Rect();
            int textHeight = (int) getTextSize();
            target.left = 0;
            target.top = (int) (getMeasuredHeight() - getTextSize()) / 2 + 1;
            target.bottom = target.top + textHeight;
            target.right = (int) (textHeight * (bitmap.getWidth() / (float) bitmap.getHeight()));
            canvas.drawBitmap(bitmap, src, target, getPaint());
            canvas.translate(target.right + 2, 0);
        }

        super.onDraw(canvas);
    }
}
